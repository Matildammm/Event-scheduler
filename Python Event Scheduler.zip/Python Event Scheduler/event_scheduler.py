import datetime

events = {}

def add_event(title, description, date_str, time_str):
    try:
        event_date = datetime.datetime.strptime(date_str, "%Y-%m-%d")
        event_time = datetime.datetime.strptime(time_str, "%H:%M")
    except ValueError:
        return None

    event_datetime = datetime.datetime.combine(event_date.date(), event_time.time())

    events[title] = {
        'title': title,
        'description': description,
        'datetime': event_datetime
    }

    return events[title]

def list_events():
    if not events:
        return None

    sorted_events = sorted(events.values(), key=lambda x: x['datetime'])
    return sorted_events

def delete_event(title):
    if title in events:
        del events[title]
        return True
    else:
        return False

def search_events(keyword):
    matching_events = [event for event in events.values() if
                       keyword.lower() in event['title'].lower() or keyword.lower() in event['description'].lower()]
    return matching_events